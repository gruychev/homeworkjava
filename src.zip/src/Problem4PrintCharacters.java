/**
 * Created by Rado on 10/18/2015.
 */
public class Problem4PrintCharacters {

        public static void main(String[] args) {
            for(char c = 97; c <= 122; ++c) {
                System.out.print(c + " ");
            }
        }
    }


