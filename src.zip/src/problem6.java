/**
 * Created by Rado on 10/18/2015.
 */
import java.util.Scanner;
public class problem6 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in, "UTF-8");
        int n = Integer.parseInt(input.nextLine());
        int num=1;
        int sum=1;
        while(num < n){
            num++;
            sum +=num;

        }
        System.out.println(sum);
    }
}

